---
name: New feature
about: Request new functionality
---

<!--
Please describe the behaviour that you want to add, and why. Be as clear as possible to avoid confusion.

If you want to request multiple features that aren't directly related, then create one issue per feature.
-->
